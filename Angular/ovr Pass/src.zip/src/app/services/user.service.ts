import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http : HttpClient) { }

  checkUser(email,password){
    return this.http.get<string>('http://localhost:52814/api/user/UserLogin?emailId=iamsoharab@gmail.com&password=admin');
  }
}
